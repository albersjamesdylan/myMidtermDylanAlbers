Start the server:
node server.js

Start the front end:
ng serve --port 8081