export class Job {
    id?: any;
    title?: string;
    description?: string;
    published?: boolean;
}
