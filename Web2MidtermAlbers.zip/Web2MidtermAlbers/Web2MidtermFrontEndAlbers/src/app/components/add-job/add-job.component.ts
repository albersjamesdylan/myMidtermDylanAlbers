import { Component, OnInit } from '@angular/core';
import { Job } from 'src/app/models/job.model';
import { JobService } from 'src/app/services/job.service';

@Component({
  selector: 'app-add-job',
  templateUrl: './add-job.component.html',
  styleUrls: ['./add-job.component.css']
})
export class AddJobComponent implements OnInit {

  Job: Job = {
    title: '',
    description: '',
    published: false
  };
  submitted = false;

  constructor(private JobService: JobService) { }

  ngOnInit(): void {
  }

  saveJob(): void {
    const data = {
      title: this.Job.title,
      description: this.Job.description
    };

    this.JobService.create(data)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.submitted = true;
        },
        error: (e) => console.error(e)
      });
  }

  newJob(): void {
    this.submitted = false;
    this.Job = {
      title: '',
      description: '',
      published: false
    };
  }

}