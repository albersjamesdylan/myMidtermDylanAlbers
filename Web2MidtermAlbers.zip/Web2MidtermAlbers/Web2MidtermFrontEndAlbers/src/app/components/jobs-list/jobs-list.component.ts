import { Component, OnInit } from '@angular/core';
import { Job } from 'src/app/models/job.model';
import { JobService } from 'src/app/services/job.service';

@Component({
  selector: 'app-jobs-list',
  templateUrl: './jobs-list.component.html',
  styleUrls: ['./jobs-list.component.css']
})
export class JobsListComponent implements OnInit {

  Jobs?: Job[];
  currentJob: Job = {};
  currentIndex = -1;
  title = '';

  constructor(private JobService: JobService) { }

  ngOnInit(): void {
    this.retrieveJobs();
  }

  retrieveJobs(): void {
    this.JobService.getAll()
      .subscribe({
        next: (data) => {
          this.Jobs = data;
          console.log(data);
        },
        error: (e) => console.error(e)
      });
  }

  refreshList(): void {
    this.retrieveJobs();
    this.currentJob = {};
    this.currentIndex = -1;
  }

  setActiveJob(Job: Job, index: number): void {
    this.currentJob = Job;
    this.currentIndex = index;
  }

  removeAllJobs(): void {
    this.JobService.deleteAll()
      .subscribe({
        next: (res) => {
          console.log(res);
          this.refreshList();
        },
        error: (e) => console.error(e)
      });
  }

  searchTitle(): void {
    this.currentJob = {};
    this.currentIndex = -1;

    this.JobService.findByTitle(this.title)
      .subscribe({
        next: (data) => {
          this.Jobs = data;
          console.log(data);
        },
        error: (e) => console.error(e)
      });
  }

}